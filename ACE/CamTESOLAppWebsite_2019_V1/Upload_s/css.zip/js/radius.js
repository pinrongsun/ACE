$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('.menu_nav').css({"border-radius": "10px", "-moz-border-radius":"10px", "-webkit-border-radius":"10px"});
	$('.content_resize').css({"border-radius": "10px", "-moz-border-radius":"10px", "-webkit-border-radius":"10px"});
	// end radius Box
	 
});	